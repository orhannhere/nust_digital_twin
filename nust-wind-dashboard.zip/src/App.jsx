import WindDashboard from "./pages/WindDashboard";

function App() {
  return <WindDashboard />;
}

export default App;